import requests

getSweetWord()