import requests
def getWeather():
    url = 'https://v0.yiketianqi.com/api?version=v61&city=鄂州&appid=84955366&appsecret=n6eJDC5J'
    res = requests.get(url)
    date = res.json()
    print(date)
getWeather()