def tiangou():
    