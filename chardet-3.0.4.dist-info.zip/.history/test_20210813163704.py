import requests
def tiangou():
    url = 'https://api.muxiuge.cn/API/tiangou.php'
    res = requests.get(url=url)
    print
