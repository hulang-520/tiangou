import requests
def getWeather(city, appid=application['weather']['appid'], appsecret=application['weather']['appsecret']):
    url = 'https://v0.yiketianqi.com/api?version=v61&city={city}&appid={appid}&appsecret=n6eJDC5J'.format(city=city,
                                                                                                             appid=appid,
                                                                                                             appsecret=appsecret)
    res = requests.get(url)
    data = res.json()['data']
    return {
        'today': data[0],
        'tomorrow': data[1]
    }
getWeather()