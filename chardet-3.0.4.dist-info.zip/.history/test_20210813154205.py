import requests
def getWeather():
    url = 'https://v0.yiketianqi.com/api?version=v61&city=鄂州&appid=84955366&appsecret=n6eJDC5J'
    res = requests.get(url)
    date = res.json()['date']
    print(date)
getWeather()
{'cityid': '101200301', 'date': '2021-08-13', 'week': '星期五', 'update_time': '15:39', 'city': '鄂州', 'cityEn': 'ezhou', 'country': '中国', 'countryEn': 'China', 'wea': '多云
', 'wea_img': 'yun', 'tem': '23', 'tem1': '27', 'tem2': '23', 'win': '北风', 'win_speed': '4级', 'win_meter': '23km/h', 'humidity': '100%', 'visibility': '19km', 'pressure': '998', 'air': '16', 'air_pm25': '24', 'air_level': '优', 'air_tips': '空气很好，可以外出活动，呼吸新鲜空气，拥抱大自然！', 'alarm': {'alarm_type': '', 'alarm_level': '', 'alarm_content': ''}, 'aqi': {'update_time': '14:14', 'cityid': '101200301', 'city': '鄂州', 'cityEn': 'ezhou', 'country': '中国', 'countryEn': 'China', 'air': '16', 'air_level': '优', 'air_tips': '空气很好，可以外出活动，呼吸新鲜空气，拥抱大自然！', 'pm25': '24', 'pm25_desc': '优', 'pm10': '39', 'pm10_desc': '优', 'o3': '89', 'o3_desc': '优', 'no2': '7', 'no2_desc': '优', 'so2': '4', 'so2_desc': '优', 'co': '1', 'co_desc': '优', 'kouzhao': '不用佩戴口罩', 'yundong': '非常适宜运动', 'waichu': '适宜外出', 'kaichuang': '适宜开窗', 'jinghuaqi': '关闭净化器'}}