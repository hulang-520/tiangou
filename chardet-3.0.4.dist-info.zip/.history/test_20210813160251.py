import requests
import yaml
from datetime import date, datetime
# 读取yml配置
def getYmlConfig(yaml_file='config.yml'):
    file = open(yaml_file, 'r', encoding="utf-8")
    file_data = file.read()
    file.close()
    config = yaml.load(file_data, Loader=yaml.FullLoader)
    return dict(config)
config = getYmlConfig()
application = config['application']
girlfriend = config['girlfriend']
def getWeather():
    url = 'https://yiketianqi.com/api?version=v1&city=鄂州&appid=84955366&appsecret=n6eJDC5J'
    res = requests.get(url)
    res = requests.get(url)
    date = res.json()['data']
    print( date[0])
    print( date[1])
    return {
        'today': date[0],
        'tomorrow': date[1]
    }
now = datetime.now()

start = datetime.strptime(girlfriend['start_love_date'], "%Y-%m-%d")
print(start)
days = (now - start).days
print("在一起"+ str（days +"天了")