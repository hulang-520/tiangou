import requests
def getWeather():
    url = 'https://yiketianqi.com/api?version=v1&city=鄂州&appid=84955366&appsecret=n6eJDC5J'
    res = requests.get(url)
    date = res.json()
    print(date)
getWeather()
