import requests
def getWeather():
    url = 'https://v0.yiketianqi.com/api?version=v61&appid=84955366&appsecret=n6eJDC5J'
    data = {
        cityid":"101271201"
    }                                                                                                     
    res = requests.get(url)
    data = res.json()['data']
    return {
        'today': data[0],
        'tomorrow': data[1]
    }
