import requests
def getSweetWord():
    url = 'http://api.tianapi.com/txapi/saylove/index?key=ce596834fa7e8c5d9d21dee24aa98fc5'
    res = requests.get(url)
    print
    res.json()['returnObj'][0]
