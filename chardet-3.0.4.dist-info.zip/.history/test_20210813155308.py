import requests
def getWeather():
    url = 'https://yiketianqi.com/api?version=v1&city=鄂州&appid=84955366&appsecret=n6eJDC5J'
    res = requests.get(url)
    res = requests.get(url)
    date = res.json()['data']
    print( date[0])
    print( date[1])
    return {
        'today': date[0],
        'tomorrow': date[1]
    }
now = datetime.now()
print(now)
