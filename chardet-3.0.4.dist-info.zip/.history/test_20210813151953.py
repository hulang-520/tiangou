import requests
def getWeather():
    url = 'https://www.tianqiapi.com/api/?version=v1&city={city}&appid={84955366}&appsecret={n6eJDC5J }'
                                                                                                        
    res = requests.get(url)
    data = res.json()['data']
    return {
        'today': data[0],
        'tomorrow': data[1]
    }
